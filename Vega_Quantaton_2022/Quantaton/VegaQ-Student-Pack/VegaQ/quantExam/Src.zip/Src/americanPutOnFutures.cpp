#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::americanPutOnFutures(double dNotional, double dBondMaturity,
                                          double dFuturesMaturity,
                                          unsigned iFuturesTimes,
                                          double dStrike,
                                          cfl::InterestRateModel &rModel)
{
    return cfl::MultiFunction(); 
}
                                