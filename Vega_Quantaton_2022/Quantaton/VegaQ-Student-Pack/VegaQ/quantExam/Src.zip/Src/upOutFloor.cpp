#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb:: upOutFloor(const cfl::Data::CashFlow &rFloor,
                                double dUpperBarrier,
                                cfl::InterestRateModel &rModel)
{
    return cfl::MultiFunction(); 
}