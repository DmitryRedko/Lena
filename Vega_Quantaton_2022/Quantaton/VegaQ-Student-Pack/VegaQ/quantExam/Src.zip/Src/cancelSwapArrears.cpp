#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::cancelSwapArrears(const cfl::Data::Swap &rSwap,
                                          cfl::InterestRateModel &rModel)
{
    return cfl::MultiFunction();
}