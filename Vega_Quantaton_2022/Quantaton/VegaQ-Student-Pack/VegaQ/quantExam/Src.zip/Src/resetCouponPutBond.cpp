#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::resetCouponPutBond(const cfl::Data::CashFlow &rBond,
                                           double dResetCouponRate, double dRedemptionPrice,
                                           cfl::InterestRateModel &rModel)
{
    return cfl::MultiFunction();
}