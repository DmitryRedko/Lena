#include "quantExam/quantExam.hpp"

using namespace cfl;
using namespace std;

cfl::MultiFunction prb::doubleUpSwap(double dLowerBarrier, const cfl::Data::Swap &rSwap,
             cfl::InterestRateModel &rModel)
{
   return cfl::MultiFunction();  
}